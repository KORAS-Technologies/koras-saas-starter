# Koras Claude Code Skills Pack

Drop the `.claude/` folder into the root of your Koras starter repository.

## Included

- Root `.claude/CLAUDE.md`
- 12 Koras engineering skills
- 4 reusable slash-command prompts
- 4 specialist agent prompts
- External-skill installation notes

## Recommended external skills

Install current official/community-maintained equivalents for:

```bash
npx skills add https://github.com/anthropics/skills --skill frontend-design
npx skills add https://github.com/anthropics/skills --skill webapp-testing
npx skills add https://github.com/vercel-labs/agent-skills --skill react-best-practices
npx skills add https://github.com/vercel-labs/agent-skills --skill web-design-guidelines
```

Optionally add Vercel composition-pattern guidance after your component system stabilizes.

## Typical workflow

```text
/feature <request>
  -> architecture + repository search
  -> implementation
  -> React/UI review
  -> security/accessibility review
  -> tests + Playwright
  -> /review
```

Use `/test` for a verification-only pass and `/ui-review` for focused frontend review.
