# External Skills

The Koras skills in this package are project-specific. Pair them with focused external skills rather than installing many overlapping generic React skills.

Recommended:

```bash
npx skills add https://github.com/anthropics/skills --skill frontend-design
npx skills add https://github.com/anthropics/skills --skill webapp-testing
npx skills add https://github.com/vercel-labs/agent-skills --skill react-best-practices
npx skills add https://github.com/vercel-labs/agent-skills --skill web-design-guidelines
```

Suggested responsibility split:

```text
frontend-design              Visual direction and polished UI creation
react-best-practices         React/Next.js implementation quality and performance
web-design-guidelines        UX/accessibility/interface review
webapp-testing               Browser-level verification with Playwright
Koras skills                 Architecture, auth, tenancy, data, security, testing conventions
```

Avoid installing multiple skills that provide the same generic React rules unless there is a concrete gap.
